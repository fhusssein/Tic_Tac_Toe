package com.example.tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView playerOneScore, playerTwoScore;
    private Button aButtons[][] = new Button[3][3];
    private Button resetGame;

    private int playerOneScoreValue, playerTwoScoreValue, roundCount;
    boolean turnPlayer = true;

    //p1 => 0
    //p2 => 1
    //empty => 2

    int [] gameState = {2,2,2,2,2,2,2,2,2};
    //Victory Conditions
    int [][] victoryConditions = {
            {0,1,2}, {3,4,5}, {6,7,8}, // rows
            {0,3,6}, {1,4,7}, {2,5,8}, // columns
            {0,4,8}, {2,4,6} // diagonal
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main
        );

        playerOneScore = (TextView) findViewById(R.id.playerOneScore);
        playerTwoScore = (TextView) findViewById(R.id.playerTwoScore);

        resetGame = (Button) findViewById(R.id.resetButton);

        //Assigns Buttons to array
        aButtons[0][0] = findViewById(R.id.btn_1);
        aButtons[0][1] = findViewById(R.id.btn_2);
        aButtons[0][2] = findViewById(R.id.btn_3);
        aButtons[1][0] = findViewById(R.id.btn_4);
        aButtons[1][1] = findViewById(R.id.btn_5);
        aButtons[1][2] = findViewById(R.id.btn_6);
        aButtons[2][0] = findViewById(R.id.btn_7);
        aButtons[2][1] = findViewById(R.id.btn_8);
        aButtons[2][2] = findViewById(R.id.btn_9);

        //Sets on click
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                aButtons[i][j].setOnClickListener(this);
            }
        }

        playerOneScoreValue = 0;
        playerTwoScoreValue = 0;
        roundCount = 0;
        turnPlayer = true;
    }


    @Override
    public void onClick(View view) {
        //tests if buttons work
        Log.i("test", "button is clicked!");

        if(!((Button)view).getText().toString().equals("")){
            return;
        }

        String buttonID = view.getResources().getResourceEntryName(view.getId());
        //
        int gameStatePointer = Integer.parseInt(buttonID.substring(buttonID.length()-1, buttonID.length()));

        //Adds X to tile
        if(turnPlayer) {
            ((Button) view).setText("X");
            ((Button) view).setTextColor(Color.parseColor("#FFFFFF"));
            gameState[gameStatePointer-1] = 0;
            Log.i("test", "button "+gameStatePointer+" has been clicked");
        }else{
            ((Button) view).setText("O");
            ((Button) view).setTextColor(Color.parseColor("#FFFFFF"));
            gameState[gameStatePointer-1] = 1;
            Log.i("test", "button "+gameStatePointer+" has been clicked");
        }

        roundCount++;
        //If a player has won declare te winner and restart the game
        if(checkForVictor()){
            if(turnPlayer){
                playerOneScoreValue++;
                updatePlayerScore();
                Toast.makeText(this, "Player One Won!", Toast.LENGTH_SHORT).show();
                newGame();
            }else{
                playerTwoScoreValue++;
                updatePlayerScore();
                Toast.makeText(this, "Player Two Won!", Toast.LENGTH_SHORT).show();
                newGame();
            }
        } else if(roundCount == 9){
            //If all tiles are filled and no one has won restart game
            newGame();
            Toast.makeText(this,"Draw!",Toast.LENGTH_SHORT).show();
        }else{
            turnPlayer = !turnPlayer;
        }

        resetGame.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                newGame();
                playerOneScoreValue = 0;
                playerTwoScoreValue = 0;
                updatePlayerScore();
            }
        });

    }

    // checks if victory conditions were achieved
    public boolean checkForVictor() {
        boolean victor = false;
        for (int[] victoryConditions: victoryConditions){
            if(gameState[victoryConditions[0]] == gameState[victoryConditions[1]] &&
                    gameState[victoryConditions[1]] == gameState[victoryConditions[2]]
                    && gameState[victoryConditions[0]] != 2){
                victor = true;
            }
        }
        return victor;
    }

    public void updatePlayerScore(){
        playerOneScore.setText(Integer.toString(playerOneScoreValue));
        playerTwoScore.setText(Integer.toString(playerTwoScoreValue));
    }

    public void newGame(){
        roundCount = 0;
        turnPlayer = true;

        for (int i = 0; i < 3; i++) {
            gameState[i] = 2;
            for (int j = 0; j < 3; j++) {
                aButtons[i][j].setText("");
            }
    }
}
}